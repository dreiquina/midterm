<!DOCTYPE html>
<html>
<head>
	<title>	</title>
	<link rel = "stylesheet"
			href = "index2.css">


</head>
<body>
	<div class="login-page">
  <div class="form">
    <form class="login-form">
      <button type  = "submit" name = "login"><a href="login.php">Logout</a></button>
      <p class="message">Not registered? <a href="login.php">Create an account</a></p>
    </form>
  </div>
</div>


</body>
</html>