<?php
$link = mysqli_connect("localhost","root","");
mysqli_select_db($link,"infoassu");

?>


<!DOCTYPE html>
<html>
<head>
	<title>	</title>
	<link rel = "stylesheet"
			href = "index.css">


</head>
<body background="cvsuimus.jpg">
	<div class="login-page">
  <div class="form">
    <form class="login-form">
      <input type="text" placeholder="username" name = "user"/>
      <input type="password" placeholder="password" name = "pass"/>
      <button type  = "submit" name = "login">login</button>
      <p class="message">Not registered? <a href="login.php">Create an account</a></p>
    </form>
  </div>
</div>

<?php
if(isset($_GET['login'])){
$n1=$_GET['user'];
$n2=$_GET['pass'];
$tb2="SELECT * FROM `admin` WHERE `user` = '".$n1."' and `pass` = '".$n2."'";

if($result=mysqli_query($link,$tb2)){
  $check = mysqli_num_rows($result);
}
if($check>0){
  header("Location: correct.php");
}
else{
  echo '<script>alert("Login Failed")</script>'; 
}
}
?>



</body>
</html>
